package com.example.listepizzas2

class Model (val title: String, val description: String, val img: Int ){
}